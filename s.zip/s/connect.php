<?php

$servername = "localhost";
$username = "afsal";
$password = "12345";
$dbname = "qas";

?>