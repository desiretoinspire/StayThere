{code type=PHP}<?php phpinfo();
?>{/code}