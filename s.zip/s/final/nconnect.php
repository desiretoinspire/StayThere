<?php
session_start();
$servername = "mysql.hostinger.in";
$username = "u864388641_12345";
$password = "9605600519";
$dbname = "u864388641_12345";

if (strcmp($_SESSION['session_role'], "admin") <> 0)
{
	  session_unset();
	  header('Location: ' . "http://staytherenitc.esy.es/index.php?reset=1"); //redirect user back to page
}
?>